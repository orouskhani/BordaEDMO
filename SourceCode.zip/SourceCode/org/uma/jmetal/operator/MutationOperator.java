package org.uma.jmetal.operator;

import org.uma.jmetal.solution.Solution;

/**
 * Created by Antonio J. Nebro on 05/09/14.
 */
public interface MutationOperator<Source extends Solution> extends Operator<Source, Source> {
}
